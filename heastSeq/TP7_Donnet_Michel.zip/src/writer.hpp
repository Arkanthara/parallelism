#ifndef __WRITER_HPP__
#define __WRITER_HPP__


void write_to_bmp(int N, std::vector<double>& data, int iter, double minval, double maxval);

#endif
