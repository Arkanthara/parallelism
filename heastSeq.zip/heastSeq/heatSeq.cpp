#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include "writer.h"

using namespace std;

const int max_iter =1e5;
const int Nx = 100;
const int Ny = 100;

int main(int argc, char* argv[])
{



    std::vector<std::vector<double>> U;
    std::vector<std::vector<double>> U0;

    U.resize(Nx);
    U0.resize(Nx);

    for(int i =0; i<Nx;++i)
    {
        U[i].resize(Ny);
        U0[i].resize(Ny);
    }

    //Assign
    for(int i =1; i< Nx-1; i++)
        for(int j =1; j< Ny -1; j++)
            {
                U[i][j] = 0;
                U0[i][j] = 0;
            }
    // Top Bottom
    for(int i =0; i< Nx; i++)
        {
            U[i][0] = 1;
            U0[i][0] = 1;
            U[i][Ny-1] = 1;
            U0[i][Ny-1] = 1;
        }

    //Left Right
     for(int i =0; i< Ny; i++)
        {
            U[0][i] = 1;
            U0[0][i] = 1;
            U[Nx-1][i] = 1;
            U0[Nx -1][i] = 1;

        }

    auto hx = 1./Nx;
    auto hy = 1./Ny;

    auto C = 1.;

    auto dt = 0.25*hx*hx/C;

    auto diagx = -2.0 + hx*hx/(2*C*dt);
    auto diagy = -2.0 + hy*hy/(2*C*dt);
    auto weightx = C*dt/(hx*hx);
    auto weighty = C*dt/(hy*hy);

    //FILL
    for(int iT = 0; iT < max_iter;iT++)
    {

        for (int i=1;i<Nx-1;i++)
            for (int j=1;j<Ny-1;j++)
                U[i][j] = weightx*(U0[i-1][j] + U0[i+1][j] + U0[i][j]*diagx) + weighty*(U0[i][j-1] + U0[i][j+1] + U0[i][j]*diagy);
    
    
    swap(U,U0);
    
    }
    
    write_to_bmp(Nx,U0,max_iter,0,1);


    return 0;

}

