#ifndef __GLOBAL_HPP__
#define __GLOBAL_HPP__

const int chunk_size = 2048;

#endif
