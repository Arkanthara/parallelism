#ifndef __WRITER_H__
#define __WRITER_H__


void write_to_bmp(int N, std::vector<double>& data, int iter, double minval, double maxval);

#endif
